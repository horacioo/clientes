<?php

const configuracao = array(
    "cliente_novo"     => 5,
    "email_de_retorno" => "contato@regisepennaseguros.com.br",
    "titulo_email"     => "Regisepenna corretora de seguros",
);
