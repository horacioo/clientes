<?php

namespace Planet1;

use Planet1\DataBase as banco;

class Formulario {



}