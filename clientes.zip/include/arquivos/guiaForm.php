<div id="guiaForm" style="
     border: 1px solid #d2d2d2;
     border-radius: 5px;
     margin-top: 2%;
     padding: 18px;
     background-color: white;
     ">
    <h2>Criando um formulário :</h2>
    <h3>
        Os códigos em preto são obrigatórios, os demais são opcionais, ficando a cargo da pessoa escolher qual atende melhor a necessidade
    </h3>
    <h4>Esse formulário deverá ser inserido nas páginas ou posts</h4>
    <br><strong>[formulario]</strong>
    <ul>
        <li><span  style="color: #008000;">[nome]</span></li>
        <li><span  style="color: #008000;">[cpf]</span></li>
        <li><span  style="color: #008000;">[tipo_de_pessoa]</span></li>
        <li><span  style="color: #008000;">[sexo]</span></li>
        <li><span  style="color: #008000;">[data_de_expedicao]</span></li>
        <li><span  style="color: #008000;">[documento]</span></li>
        <li><span  style="color: #008000;">[estado_civil]</span></li>
        <li><span  style="color: #008000;">[data_de_nascimento]</span></li>
        <li><span  style="color: #008000;">[email]</span></li>
        <li><span  style="color: #008000;">[telefone]</span></li>
        <li><span  style="color: #008000;">[botao]</span></li>
        <li><span  style="color: #008000;">[interesse]valor1,valor2,valor3[/interesse]</span></li>
    </ul>
    <br><strong>[fim_do_formulario]</strong>
    <br><strong> [Recebe-Form]</strong>
</div>